#!/usr/bin/env python3

import sys
import traceback
import gi

gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, Gio, GLib

print ("save all plugin started")

class MergeAllLayersPlugin(Gimp.PlugIn):

    def do_query_procedures(self):
        return ["python-fu-merge-all-layers"]

    def do_create_procedure(self, name):
        procedure = Gimp.ImageProcedure.new(
            self,
            name,
            Gimp.PDBProcType.PLUGIN,
            self.run,
            None
        )

        procedure.set_menu_label("Merge ALL Layers")
        procedure.add_menu_path("<Image>/File")

        procedure.set_documentation(
            "Merge all layers in all open images",
            "Loops through all open images and merges visible layers",
            name
        )

        procedure.set_attribution(
            "You", "You", "2026"
        )

        return procedure

    def run(self, procedure, run_mode, image, drawables, config, data):
        try:
            print("Running merge all layers plugin")

            images = list(Gimp.get_images())
            print(f"Found {len(images)} images")

            for img in images:
                print(f"Merging: {img.get_name()}")
                img.merge_visible_layers(Gimp.MergeType.CLIP_TO_IMAGE)

            return procedure.new_return_values(
                Gimp.PDBStatusType.SUCCESS, None
            )

        except Exception as e:
            print("ERROR:", e)
            traceback.print_exc()

            return procedure.new_return_values(
                Gimp.PDBStatusType.EXECUTION_ERROR,
                GLib.Error(message=str(e))
            )

Gimp.main(MergeAllLayersPlugin.__gtype__, sys.argv)
