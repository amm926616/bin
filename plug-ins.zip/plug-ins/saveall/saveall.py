#!/usr/bin/env python3

import sys
import gi
import traceback

gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib

print("save all plugin started")


class SaveAllImagesPlugin(Gimp.PlugIn):

    def do_query_procedures(self):
        return ["python-fu-save-all-images"]

    def do_create_procedure(self, name):
        procedure = Gimp.ImageProcedure.new(
            self,
            name,
            Gimp.PDBProcType.PLUGIN,
            self.run,
            None
        )

        procedure.set_menu_label("Save ALL")
        procedure.add_menu_path("<Image>/File")

        procedure.set_documentation(
            "Save all opened images to their original files",
            "Iterates all open images and saves them to their existing file paths",
            name
        )

        procedure.set_attribution(
            "You", "You", "2026"
        )

        return procedure

    def run(self, procedure, run_mode, image, drawables, config, data):
            try:
                images = list(Gimp.get_images()) # Consistent API call
                
                for img in images:
                    gfile = img.get_file()

                    if not gfile:
                        print(f"Skipping {img.get_name()}: No file path associated.")
                        continue

                    # In GIMP 3, file_save does NOT take a drawable anymore
                    # It saves the image state to the provided GFile
                    success = Gimp.file_save(
                        Gimp.RunMode.NONINTERACTIVE,
                        img,
                        gfile
                    )

                    if success:
                        img.clean_all() # Mark as not modified
                        print(f"Saved: {img.get_name()}")

                return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, None)

            except Exception as e:
                return procedure.new_return_values(
                    Gimp.PDBStatusType.EXECUTION_ERROR,
                    GLib.Error(message=str(e))
                )

Gimp.main(SaveAllImagesPlugin.__gtype__, sys.argv)